# SA Calculator Tools Only v100.19

## Root-cause correction
- Linked `assets/css/tools-only.css` from the app shell after the other presentation stylesheets. The stylesheet already contained the Tools-only visibility rules but was not loaded by `index.html`.
- The Tools-only stylesheet is included in the Android web bundle and service-worker precache; bumped the cache key to `sa-calculator-tools-only-v10019` so installed clients do not reuse the prior shell cache.
- Renamed the tool catalogue section's accessible label from the stale `Other Calculator` label to `Tools` and corrected the app description to describe the 12-tool edition.
- Added regression coverage proving the stylesheet is linked last, copied to Android, precached, and hides legacy Home/Calculator/Settings/Favorites/History surfaces.

## Cleanup
- Removed obsolete historical release-note files from the project payload; retained the current release notes, README, and reference audit document.
- Kept the standalone workflow YAML alongside `.github/workflows/main.yml` and verified the copies are identical.
- Preserved all 12 tools, their existing calculations, selectors, keypad and result behavior.

## Release identity
- Package version: `2.0.17-v100.19`
- Android versionCode: `1099158`

## Verification
- `npm run build:web`: passed; 13 required assets verified.
- `npm run test:release`: 91 tests passed, 0 failed.
- JavaScript syntax checks: passed.
- YAML parsing: passed.
- ZIP integrity: passed.
- A GitHub-hosted Android APK build and physical-device visual check have not yet been performed for this release.
