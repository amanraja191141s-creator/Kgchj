import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const y=fs.readFileSync(new URL('../.github/workflows/main.yml',import.meta.url),'utf8');
test('Android build uses persistent Gradle dependency and task cache',()=>{
 assert.match(y,/gradle\/actions\/setup-gradle@v4/);
 assert.match(y,/--build-cache/);
 assert.match(y,/--parallel/);
 assert.match(y,/--max-workers=2/);
 assert.doesNotMatch(y,/--no-daemon/);
});
test('npm download cache is keyed by project package manifest',()=>{
 assert.match(y,/actions\/cache@v4/);
 assert.match(y,/hashFiles\('\*\*\/package\.json', '\*\*\/SA-Calculator-Tools-Only\*\.zip'\)/);
});
test('Android Gradle memory and worker settings are bounded',()=>{
 assert.match(y,/org\.gradle\.jvmargs=-Xmx3g/);
 assert.match(y,/org\.gradle\.workers\.max=2/);
 assert.match(y,/org\.gradle\.caching=true/);
});
test('APK upload avoids recompressing the already compressed APK',()=>{
 assert.match(y,/compression-level: 0/);
});
